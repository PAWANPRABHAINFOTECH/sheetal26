import { useState } from 'react'
import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { Loader2, Eye, EyeOff } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card'
import logoAsset from '@/assets/logo.png.asset.json'
import { supabase } from '@/integrations/supabase/client'
import { useAdminAuth } from '@/lib/admin/useAdminAuth'


export const Route = createFileRoute('/admin/login')({
  ssr: false,
  head: () => ({
    meta: [
      { title: 'शीतल शिवालय समिति | एडमिन लॉगिन' },
      { name: 'robots', content: 'noindex, nofollow' },
      { name: 'description', content: 'अधिकृत प्रशासक के लिए सुरक्षित लॉगिन।' },
    ],
  }),
  component: AdminLoginPage,
})

function AdminLoginPage() {
  const { session, loading } = useAdminAuth()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-muted/30">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (session) {
    void navigate({ to: '/admin/dashboard', replace: true })
    return null
  }

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault()
    setSubmitting(true)
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    setSubmitting(false)
    if (error) {
      toast.error('लॉगिन विफल: ईमेल या पासवर्ड गलत है')
      return
    }
    toast.success('स्वागत है')
    void navigate({ to: '/admin/dashboard', replace: true })
  }

  const handleForgotPassword = async () => {
    if (!email) {
      toast.error('कृपया पहले अपना ईमेल दर्ज करें')
      return
    }
    
    // Use window.location.origin to ensure it works in preview and production.
    // Explicitly using the current origin for the redirect.
    const origin = window.location.origin;
    const redirectTo = `${origin}/auth/callback?type=recovery`;
    console.log("Password reset redirect:", redirectTo);
    
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: redirectTo,
    })
    if (error) {
      toast.error('त्रुटि: ' + error.message)
    } else {
      toast.success('पासवर्ड रीसेट लिंक आपके ईमेल पर भेज दिया गया है')
    }
  }

  return (
    <div className="min-h-screen bg-muted/30 flex items-center justify-center p-4 font-hindi">
      <Card className="w-full max-w-md border-none shadow-2xl rounded-3xl overflow-hidden">
        <CardHeader className="bg-primary text-primary-foreground text-center py-10">
          <img
            src={logoAsset.url}
            alt="शीतल शिवालय समिति"
            className="h-20 w-20 mx-auto mb-4 bg-white rounded-full p-2"
          />
          <CardTitle className="font-hindi text-2xl">एडमिन लॉगिन</CardTitle>
        </CardHeader>
        <CardContent className="p-8">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div className="space-y-2">
              <label className="font-bold">ईमेल</label>
              <Input
                type="email"
                required
                autoComplete="username"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@example.com"
              />
            </div>
            <div className="space-y-2 relative">
              <label className="font-bold">पासवर्ड</label>
              <div className="relative">
                <Input
                  type={showPassword ? 'text' : 'password'}
                  required
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground focus:outline-none"
                  aria-label={showPassword ? 'पासवर्ड छुपाएं' : 'पासवर्ड दिखाएं'}
                  tabIndex={-1}
                >
                  {showPassword ? (
                    <EyeOff className="h-5 w-5" />
                  ) : (
                    <Eye className="h-5 w-5" />
                  )}
                </button>
              </div>
            </div>
            <Button type="submit" disabled={submitting} className="w-full py-6 text-lg bg-primary">
              {submitting && <Loader2 className="mr-2 h-5 w-5 animate-spin" />}
              लॉगिन करें
            </Button>
            <div className="text-center space-y-2">
              <p className="text-sm text-muted-foreground">
                केवल अधिकृत प्रशासक ही लॉगिन कर सकते हैं।
              </p>
              <button
                type="button"
                onClick={handleForgotPassword}
                className="text-sm text-primary hover:underline font-bold"
              >
                पासवर्ड भूल गए? (Reset Password)
              </button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
