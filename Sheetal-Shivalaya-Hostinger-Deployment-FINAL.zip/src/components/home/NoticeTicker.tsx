import { useNotices } from "@/lib/temple.hooks";
import { Megaphone } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { useLanguage } from "@/lib/i18n";


export function NoticeTicker() {
  const { data: notices, isLoading } = useNotices();
  const { t } = useLanguage();


  // Filter only current notices based on date if present
  const activeNotices = notices?.filter(notice => {
    if (!notice.is_active) return false;
    const now = new Date();
    if (notice.start_date && new Date(notice.start_date) > now) return false;
    if (notice.end_date && new Date(notice.end_date) < now) return false;
    return true;
  }) || [];

  if (isLoading) return null;

  // Master/locked speed: the current 2-notice ticker runs one full loop in 25s.
  // Keep pixels-per-second constant by scaling duration with the number of notices.
  const SECONDS_PER_NOTICE = 12.5;
  const marqueeDuration = `${Math.max(activeNotices.length, 2) * SECONDS_PER_NOTICE}s`;

  return (
    <div className="bg-primary text-primary-foreground h-[36px] md:h-[42px] overflow-hidden flex items-center relative z-[60]">
      <div className="flex items-center h-full px-4 bg-primary z-10 shadow-[4px_0_8px_rgba(0,0,0,0.2)] dark:shadow-none">
        <Megaphone className="h-4 w-4 mr-2 animate-bounce" />
        <span className="font-hindi text-sm font-bold whitespace-nowrap">{t('notice.label')}</span>
        <span className="mx-2 opacity-50">|</span>
      </div>
      
      <div className="flex-1 overflow-hidden relative h-full flex items-center">
        <div className="flex animate-marquee hover:pause-marquee whitespace-nowrap" style={{ animationDuration: marqueeDuration }}>

          {activeNotices.length > 0 ? activeNotices.map((notice, idx) => (
            <div key={notice.id} className="inline-flex items-center px-4">
              {notice.link_url ? (
                notice.link_url.startsWith('/') ? (
                  <Link 
                    to={notice.link_url as any}
                    className="font-hindi text-sm hover:text-secondary transition-colors"
                  >
                    {notice.content}
                    {notice.link_text && (
                      <span className="ml-2 underline decoration-dotted">{notice.link_text}</span>
                    )}
                  </Link>
                ) : (
                  <a 
                    href={notice.link_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-hindi text-sm hover:text-secondary transition-colors"
                  >
                    {notice.content}
                    {notice.link_text && (
                      <span className="ml-2 underline decoration-dotted">{notice.link_text}</span>
                    )}
                  </a>
                )
              ) : (
                <span className="font-hindi text-sm">{notice.content}</span>
              )}
              <span className="mx-6 text-secondary/50">•</span>
            </div>
          )) : (
            <div className="inline-flex items-center px-4">
              <span className="font-hindi text-sm">शीतल शिवालय समिति, मंडीदीप में आपका स्वागत है।</span>
              <span className="mx-6 text-secondary/50">•</span>
            </div>
          )}
          {/* Duplicate for seamless scrolling */}
          {activeNotices.length > 0 ? activeNotices.map((notice, idx) => (
            <div key={`${notice.id}-dup`} className="inline-flex items-center px-4">
              {notice.link_url ? (
                notice.link_url.startsWith('/') ? (
                  <Link 
                    to={notice.link_url as any}
                    className="font-hindi text-sm hover:text-secondary transition-colors"
                  >
                    {notice.content}
                    {notice.link_text && (
                      <span className="ml-2 underline decoration-dotted">{notice.link_text}</span>
                    )}
                  </Link>
                ) : (
                  <a 
                    href={notice.link_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-hindi text-sm hover:text-secondary transition-colors"
                  >
                    {notice.content}
                    {notice.link_text && (
                      <span className="ml-2 underline decoration-dotted">{notice.link_text}</span>
                    )}
                  </a>
                )
              ) : (
                <span className="font-hindi text-sm">{notice.content}</span>
              )}
              <span className="mx-6 text-secondary/50">•</span>
            </div>
          )) : (
            <div className="inline-flex items-center px-4">
              <span className="font-hindi text-sm">शीतल शिवालय समिति, मंडीदीप में आपका स्वागत है।</span>
              <span className="mx-6 text-secondary/50">•</span>
            </div>
          )}
        </div>
      </div>
      
      <style>{`
        .animate-marquee {
          display: inline-flex;
          animation: marquee 25s linear infinite;
        }
        .pause-marquee {
          animation-play-state: paused;
        }
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  );
}
